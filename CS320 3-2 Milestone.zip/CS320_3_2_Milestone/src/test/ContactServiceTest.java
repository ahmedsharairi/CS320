package test;

import contact.Contact;
import contact.ContactService;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;

import static org.junit.jupiter.api.Assertions.*;

public class ContactServiceTest {

    private ContactService contactService;

    @BeforeEach
    void setUp() {
        contactService = new ContactService();
    }

    @Test
    void testAddContact() {
        Contact contact = new Contact("12345", "John", "Doe", "1234567890", "123 James St");
        contactService.addContact(contact);
        assertEquals(contact, contactService.getContact("12345"));
    }

    @Test
    void testDeleteContact() {
        Contact contact = new Contact("12345", "John", "Doe", "1234567890", "123 James St");
        contactService.addContact(contact);
        contactService.deleteContact("12345");
        assertNull(contactService.getContact("12345"));
    }

    @Test
    void testUpdateContact() {
        Contact contact = new Contact("12345", "John", "Doe", "1234567890", "123 James St");
        contactService.addContact(contact);
        contactService.updateContact("12345", "Jane", "Doe", "1111111111", "432 Jake St");
        Contact updatedContact = contactService.getContact("12345");
        assertEquals("Jane", updatedContact.getFirstName());
        assertEquals("Doe", updatedContact.getLastName());
        assertEquals("1111111111", updatedContact.getPhone());
        assertEquals("432 Jake St", updatedContact.getAddress());
    }
}

