package test;

import static org.junit.jupiter.api.Assertions.*;

import org.junit.jupiter.api.Assertions;
import org.junit.jupiter.api.Test;

import contact.Contact;

class ContactTest {
	
	@Test
	void testContact() {
		Contact contact = new Contact("12345", "John", "Doe", "1234567890", "123 James St");
		assertTrue(contact.getContact_ID().equals("12345"));
		assertTrue(contact.getFirstName().equals("John"));
		assertTrue(contact.getLastName().equals("Doe"));
		assertTrue(contact.getPhone().equals("1234567890"));
		assertTrue(contact.getAddress().equals("123 James St"));
	}
	
	@Test
	void testContactIDIsTooLong() {
		Assertions.assertThrows(IllegalArgumentException.class, () -> {
			new Contact("12345678910", "John", "Doe", "1234567890", "123 James St");
		}); }
	
	@Test
	void testContactIDIsNull() {
		Assertions.assertThrows(IllegalArgumentException.class, () -> {
			new Contact(null, "John", "Doe", "1234567890", "123 James St");
		}); }
	
	@Test
	void testFirstNameIsTooLong() {
		Assertions.assertThrows(IllegalArgumentException.class, () -> {
			new Contact("12345", "Johnnnnnnnnnn", "Doe", "1234567890", "123 James St");
		}); }
	
	@Test
	void testFirstNameIsNull() {
		Assertions.assertThrows(IllegalArgumentException.class, () -> {
			new Contact("12345", null, "Doe", "1234567890", "123 James St");
		}); }
	
	@Test
	void testLastNameIsTooLong() {
		Assertions.assertThrows(IllegalArgumentException.class, () -> {
			new Contact("12345", "John", "Doeeeeeeeeeee", "1234567890", "123 James St");
		}); }
	
	@Test
	void testLastNameIsNull() {
		Assertions.assertThrows(IllegalArgumentException.class, () -> {
			new Contact("12345", "John", null, "1234567890", "123 James St");
		}); }
	
	@Test
	void testPhoneIsTooLong() {
		Assertions.assertThrows(IllegalArgumentException.class, () -> {
			new Contact("12345", "John", "Doe", "12345678901011", "123 James St");
		}); }
	
	@Test
	void testPhoneIsNull() {
		Assertions.assertThrows(IllegalArgumentException.class, () -> {
			new Contact("12345", "John", "Doe", null, "123 James St");
		}); }
	
	@Test
	void testAddressIsTooLong() {
		Assertions.assertThrows(IllegalArgumentException.class, () -> {
			new Contact("12345", "John", "Doe", "1234567890", "123 James Mad ST Central Town, New York, New York, United States, North America");
		}); }
	
	@Test
	void testAddressIsNull() {
		Assertions.assertThrows(IllegalArgumentException.class, () -> {
			new Contact("12345", "John", "Doe", "1234567890", null);
		}); }
	}
