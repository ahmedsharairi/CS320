package contact;

import java.util.ArrayList;

public class ContactService {
	
	// Creates an array for the contacts
    private ArrayList<Contact> contactList = new ArrayList<>();

    //Adds contact
    public void addContact(Contact contact) {
        contactList.add(contact);
    }
    
    // Getter for contact
    public Contact getContact(String contactID) {
        for (Contact contact : contactList) {
            if (contact.getContact_ID().equals(contactID)) {
                return contact;
            }
        }
        return null;
    }
    
    //Deletes contact using ID
    public void deleteContact(String contactID) {
        for (Contact contact : contactList) {
            if (contact.getContact_ID().equals(contactID)) {
                contactList.remove(contact);
                return;
            }
        }
        System.out.println("ID: " + contactID + " cannot be found.");
    }

    // Updates the contact using the ID and provided information. If no info is provided, it does not update.
    public void updateContact(String contactID, String firstName, String lastName, String phone, String address) {
        for (Contact contact : contactList) {
            if (contact.getContact_ID().equals(contactID)) {
                if (firstName != null) {
                    contact.setFirstName(firstName);
                }
                if (lastName != null) {
                	contact.setLastName(lastName);
                }
                if (phone != null) {
                    contact.setPhone(phone);
                }
                if (address != null) {
                    contact.setAddress(address);
                }
                return;
            }
        }
        
        System.out.println("ID: " + contactID + " cannot be found.");
        
    }
}